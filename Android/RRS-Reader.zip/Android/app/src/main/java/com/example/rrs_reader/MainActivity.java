package com.example.rrs_reader;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.example.rrs_reader.models.RSSSite;
import com.example.rrs_reader.networking.interfaces.RSSService;
import com.example.rrs_reader.networking.repositories.RSSRepository;

import java.net.MalformedURLException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            RSSRepository repository = RSSRepository.getInstance("https://vnexpress.net/rss/khoa-hoc.rss").initializeService();

            repository.getRSS().enqueue(new Callback<RSSSite>() {
                @Override
                public void onResponse(@NonNull Call<RSSSite> call, @NonNull Response<RSSSite> response) {
                    if (response.isSuccessful()) {
                        Log.i("Site", response.body().getTitle().toString());
                    }
                }

                @Override
                public void onFailure(@NonNull Call<RSSSite> call, @NonNull Throwable t) {
                    Log.e("Get RSS failed:", t.getMessage());
                }
            });
        } catch (Exception e) {
            Log.e("RSS", "Invalid Url");
        }
    }
}