package com.example.rrs_reader.networking.repositories;

import com.example.rrs_reader.models.RSSSite;
import com.example.rrs_reader.networking.clients.RetrofitClient;
import com.example.rrs_reader.networking.interfaces.RSSService;

import java.net.MalformedURLException;
import java.net.URL;

import retrofit2.Call;


public class RSSRepository {
    private RSSRepository() {
    }

    private static String base;
    private static String path;
    private RSSService service;
    private static volatile RSSRepository instance = null;

    public static RSSRepository getInstance(String url) throws MalformedURLException {
        String base;
        String path;
        try {
            URL link = new URL(url);
            base = link.getProtocol() + "://" + link.getHost() + '/';
            path = link.getPath();

            if (instance == null)
                instance = new RSSRepository();

            RSSRepository.base = base;
            RSSRepository.path = path;

            return instance;
        } catch (MalformedURLException e) {
            throw e;
        }
    }

    public RSSRepository initializeService() {
        this.service = RetrofitClient.getClient(base).create(RSSService.class);

        return instance;
    }

    public Call<RSSSite> getRSS() throws Exception {
        if (this.service != null)
            return this.service.getRSS(path);
        else
            throw new Exception("Service isn't initialized");
    }
}
