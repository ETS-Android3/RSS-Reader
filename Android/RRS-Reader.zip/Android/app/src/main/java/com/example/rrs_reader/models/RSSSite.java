package com.example.rrs_reader.models;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Path;
import org.simpleframework.xml.Root;
import org.simpleframework.xml.Text;

import java.util.List;

@Root(name = "rss", strict = false)
public class RSSSite {
    @Element(name = "title", required = true, data = true)
    @Path("channel")
    private String title;

    @ElementList(entry = "item", inline = true, required = true)
    @Path("channel")
    private List<RSSArticle> list;


    public RSSSite() {
    }

    public String getTitle() {
        return title;
    }

    public List<RSSArticle> getList() {
        return list;
    }
}
